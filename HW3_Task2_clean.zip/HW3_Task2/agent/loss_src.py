
import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import importlib 
import math


def compute_loss(model, target, states, actions, rewards,rewards_MC, next_states, dones,device = 'cpu',batch_size = 32,gamma=0.98,alpha_MC=0.5,methode='DQN'):
    
    # resize tensors
    actions = actions.view(actions.size(0), 1).to(device)
    dones = dones.view(dones.size(0), 1).int().to(device)

    next_states = next_states.float().to(device)
    states = states.float().to(device)
    rewards = rewards.to(device)
    rewards_MC = rewards_MC.to(device)

    # compute loss
    next_Q = target.forward(next_states)
    curr_Q = model.forward(states).gather(1, actions)
    
    max_next_Q = (torch.max(next_Q, 1)[0])
    max_next_Q = (max_next_Q.view(max_next_Q.size(0), 1))
    
    expected_Q = (rewards + (1 - dones.int()) * gamma * max_next_Q)
    if methode =='MC':
      # Adding monteCarlo term based
      expected_Q= expected_Q*(1-alpha_MC) + alpha_MC * rewards_MC
    
    loss = F.mse_loss(curr_Q, expected_Q) 

    return loss



def optimize(model, target, memory, optimizer,device = 'cpu',batch_size = 32,methode='DQN'):
    '''
    Optimize the model for a sampled batch with a length of `batch_size`
    '''
    batch = memory.sample(batch_size)
    loss = compute_loss(model, target, *batch,device = device,batch_size = batch_size,methode=methode)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    return loss

def compute_epsilon(episode,min_epsilon,max_epsilon,epsilon_decay):
    '''
    Compute epsilon used for epsilon-greedy exploration
    '''
    epsilon = min_epsilon + (max_epsilon - min_epsilon) * math.exp(-1. * episode / epsilon_decay)
    return epsilon

def compute_reward(reward,action,done,t,mode='Normal'):

  if mode == 'Dense':
    if done and reward < 10:
      # Si crash
      return(-5)
    if not(done) and action == 2 and t<=37:
      # Si action rapide
      return(1)
    if not(done) and action == 3 and t<=38:
      # action mi rapide 
      return(0.5)
  return(reward)



def monteCarloUpdateClean(memory,nb_steps=3,discount_factor=0.8,time_ep=0):
  
  cur_memory = memory.current_number
  for i in range(0,time_ep):
    cur_iter = cur_memory - time_ep + i
    time_last = time_ep - i 
    _nb_steps = min(nb_steps,time_last)
    cur_r = 0
    for j in range(0,_nb_steps):
      cur_r += (discount_factor**j) * memory.buffer[cur_iter+j].reward[0]

    memory.buffer[cur_iter] = memory.buffer[cur_iter]._replace(rewardMC = [cur_r])
    cur_iter +=1