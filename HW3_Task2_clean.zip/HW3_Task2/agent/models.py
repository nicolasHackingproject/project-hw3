import torch
import torch.autograd as autograd
import torch.nn as nn
import gym
import gym_grid_driving
import collections
import numpy as np
import random
import math
import os
from . import state_change
import sys
import time


#from .env import construct_task2_env,construct_task2_env_ij,construct_task2_env_ij_lanes
#from buffer_src import ReplayBuffer
#from agent import ConvDQN 
from . import buffer_src
from .agent import ConvDQN
from . import agent
import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from . import loss_src 
import importlib 
#import env 

importlib.reload(loss_src)
importlib.reload(agent)
try:
  
  #importlib.reload(env)
  importlib.reload(buffer_src)
  #importlib.reload(ConvDQN)
except:pass

#from loss_src import compute_epsilon,compute_loss,optimize,monteCarloUpdateClean
from gym_grid_driving.envs.grid_driving import LaneSpec


script_path = os.path.dirname(os.path.realpath(__file__))
date_save = time.strftime("%d %H %M")
model_path = os.path.join(script_path, 'model_{}.pt'.format(date_save))

def train(model_class, env,pretrain=False,model_p= None,savepath='',config=None,cropping=False):

    #Init 
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device is:",device)

    # Hyperparameters --- don't change, RL is very sensitive
    learning_rate = 0.001
    gamma         = 0.98
    # buffer_limit = 5000
    buffer_limit  = 8000
    #batch_size    = 128
    t_max         = 600
    min_buffer    = 4000
    target_update = 200 # episode(s)
    train_steps   = 10
    min_epsilon   = 0.01
    print_interval = 50
    Transition = collections.namedtuple('Transition', ('state', 'action', 'reward','rewardMC', 'next_state', 'done'))
    Config = collections.namedtuple('Config', ('x_debut', 'y_debut', 'max_episode', 'max_epsilon', 'epsilon_decay', 'test_interval','save_interval','batch_size','buffer_limit','methode','gamma_nstep','nstep'))
    Cropping_confing = collections.namedtuple('cropping_config', ('x_debut', 'y_debut', 'hauteur','largeur','devant','derriere'))
    # Reinitialze rewards and losses
    #Config 
    #config_x = config[etape]
    x_debut = config.x_debut
    y_debut = config.y_debut
    max_episodes = config.max_episode
    max_epsilon = config.max_epsilon
    epsilon_decay = config.epsilon_decay
    test_interval = config.test_interval
    save_interval = config.save_interval
    batch_size = config.batch_size
    buffer_limit = config.buffer_limit
    #nb_steps_update = config.nb_steps_update
    methode = config.methode
    gamma_nstep = config.gamma_nstep
    nstep = config.nstep
    largeur = config.largeur
    hauteur = config.hauteur
    min_buffer = config.min_buffer
    speedy = config.speedy
    devant = config.devant
    derriere = config.derriere
    
    # Lane configurations
    lane_d = config.lane_d
    lane_f = config.lane_f

    largeur = devant+derriere+1
    cropping_config = Cropping_confing(x_debut,y_debut,hauteur,largeur,devant,derriere)

    # Dim space for cropping -> The agent learn only on a subspace 
    if cropping:
      #Largeur + 1 because cropping centred on x position 
      dim_space = (4,hauteur,largeur)
    else:
      dim_space = env.observation_space.shape
    print(dim_space)
    # Initialize model and target network
    if not(pretrain):
      model = model_class(dim_space, env.action_space.n,device = device,cropping=cropping_config).to(device)
    # If pretrain load model 
    if pretrain: 
      model = model_class(dim_space, env.action_space.n,device = device,cropping=cropping_config).to(device)
      model.load_state_dict(model_p.state_dict())
      model.eval()

    #Inititialize target
    target = model_class(dim_space, env.action_space.n,device = device,cropping=cropping_config).to(device)
    target.load_state_dict(model.state_dict())
    target.eval()

    # Initialize rewards, losses, and optimizer
    rewards = []
    losses = []
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    # Initialize replay buffer
    memory = buffer_src.ReplayBuffer(buffer_limit=buffer_limit)

    #Print learning configuration
    print("config : \n x debut {}, y_debut {}, max ep {}, max epsilon {} \n Epsilon_decay {}, test_interval {}".format(x_debut,y_debut,max_episodes,max_epsilon,epsilon_decay,test_interval))
    print("Save_interval {}, batch_size {}, buffer_limit {} \n Methode {}, gamma_nstep {}, nstep {}".format(save_interval,batch_size,buffer_limit,methode,gamma_nstep,nstep))
    print("Dim crop largeur,hauteur {},{} min buffer {} \n lane_d,lane_f {},{}".format(largeur,hauteur,min_buffer,lane_d,lane_f))
    
    # For printing timing reaching goal and avg rewards
    printing_reward = []
    timing = []
    
    #Init environment
    state = env.reset()
    print("Start learning from : x_debut {} y_debut {}".format(x_debut,y_debut))

    for episode in range(max_episodes):

        # Do testing to check performance during learning and stop training if performance are sufiscient 
        if episode % test_interval == 0 and episode > 0 or (episode == max_episodes-1):
          print("Testing: t1,t2 : {},{}".format(x_debut,int(4/5*x_debut)))
          scores = mainTest(model,runs=50,env=env,t1=x_debut,t2=int(4/5*x_debut),cropping=cropping_config)
          if scores > 8.8:
            print("Double check Testing: t1,t2 : {},{}".format(x_debut,int(4/5*x_debut)))
            scores = mainTest(model,runs=100,env=env,t1=x_debut,t2=int(4/5*x_debut),cropping=cropping_config)
            # if scores > 8.5 two times stop training 
            if scores > 8.8 :
              print("Training should stop")
              break  

        #Initi episode : epsilon, state reset
        epsilon = loss_src.compute_epsilon(episode,0.01,max_epsilon,epsilon_decay)
        state = env.reset()
        episode_rewards = 0.0
        

        for t in range(t_max):
            # Model takes action
            action = model.act(state,cropping=cropping_config,epsilon = epsilon)
            reward_mana = 0 
            # Apply the action to the environment
            next_state, reward, done, info = env.step(action)

            #Cropping state for learning
            state = state_change.state_from_pos(state,cropping=cropping_config)
            next_state_pushed = state_change.state_from_pos(next_state,cropping=cropping_config)

            #Compute reward  
            #Store init reward
            rewardInit = reward
            if methode=='MC':
              #reward shapping 
              reward = loss_src.compute_reward(reward,action,done,t,mode='Normal')

            if speedy:
              pos_x,pos_y = state_change.pos_from_state(state)
              npos_x,npos_y = state_change.pos_from_state(next_state)
              
              if not(done) and action == 2:
                reward = 0.2
              elif not(done) and action == 3:
                reward = 0.1

              if reward == 10:
                reward = 10


              '''
              if done and reward == 0:
                reward = 0
              if not(done) and reward !=10:
                reward = 0
            
             
              if action == 2:
                reward_mana = 0.2
              if action ==3:
                reward_mana = 0.1 
              
              
              reward_mana = (pos_x-npos_x)/10 - 0.1 + (pos_y-npos_y)/5 
              '''

            if done and reward == 0:
              reward = 0

            elif not(done) and reward ==0:
              reward = reward_mana

            # Save transition to replay buffer  
            # Adding a list of rewards MonteCarlo to compute rewards based on Mixed MonteCarlo method with DQN
            memory.push(Transition(state, [action], [reward],[0] ,next_state_pushed, [done]))
            
            state = next_state
            episode_rewards += reward
          
            if done:
                rewards.append(episode_rewards)  
                if rewardInit == 10 and t<=40 and x_debut == 49:
                  printing_reward.append(20)
                elif rewardInit == 10: 
                  #Print timing and 10 if goal reached 
                  printing_reward.append(10)
                  timing.append(t)
                else:
                  printing_reward.append(0)
                break
        
        #Update memory with MonteCarlo update rewards 
        if methode =='MC':
          loss_src.monteCarloUpdateClean(memory,nb_steps=nstep,discount_factor=gamma_nstep,time_ep=t)
        
        # Train the model if memory is sufficient
        if len(memory) > min_buffer:
            for i in range(train_steps):
                #Update loss
                loss = loss_src.optimize(model, target, memory, optimizer,device = device,batch_size = batch_size,methode=methode)
                losses.append(loss.item())

        # Update target network every once in a while
        if episode % target_update == 0:
            target.load_state_dict(model.state_dict())

        # Saving model (tahnks google colab for crashing)
        if episode % save_interval == 0 and episode > 0:
          try:
            data = (model.__class__.__name__, model.state_dict(), model.input_shape, model.num_actions)
            torch.save(data, savepath+'_cb_{}_{}_{}.pt'.format(save_interval,x_debut,y_debut))
          except:
            print("Error while saving middle model ")

        # Do printing of results
        if episode % print_interval == 0 and episode > 0:
            
              # Print result of last episodes
              cur_print = print_interval*((episode//print_interval)-1)
              int_list = np.array(list(map(int,printing_reward[cur_print:])))
              r40 = np.count_nonzero(int_list == 20)
              r50 = np.count_nonzero(int_list == 10)
              #Percentage of goal reached with good and bad timings
              try:
                per40 = (r40 / len(int_list)) *100
                per50 = (r50 / len(int_list)) *100
              except:
                per40 = None 
                per50 = None
              # Global print
              print("[Episode {}]\t rewards globals : {:.3f} \tavg rewards : {:.3f},\t avg timing {} \tavg loss: : {:.6f},\tbuffer size : {},\tepsilon : {:.1f}%, \t r <=40 {}, \t r > 40 {}".format(
                              episode, np.mean(printing_reward),np.mean(printing_reward[cur_print:]),np.mean(timing[-10:]), np.mean(losses), len(memory), epsilon*100,per40,per50))
            
    
    #Save model after training 
    try:
      object_export = [max_episodes,printing_reward,losses]
      torch.save(object_export, savepath+'_history_lastcb.pt')
    except:
      print("error while saving history final")  
    try:
      data = (model.__class__.__name__, model.state_dict(), model.input_shape, model.num_actions)
      torch.save(data, savepath + '{}_{}_{}_{}_{}_f.pt'.format(methode ,x_debut,y_debut,lane_d,lane_f))
    except:
      print("error while saving model final")

    return model    

def get_model(modelpath='',device='cpu',cropping=None):
    '''
    Load `model` from disk. Location is specified in `model_path`. 
    '''
    #Init 
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("model loaded to device is:",device)
    model_class, model_state_dict, input_shape, num_actions = torch.load(modelpath,map_location=torch.device(device))
    if cropping:
      dim_space = cropping.dim_space
    else:
      dim_space = input_shape
    model = eval(model_class)(dim_space, num_actions,device = device,cropping=cropping).to(device)
    model.load_state_dict(model_state_dict)
    return model

def save_model(model):
    '''
    Save `model` to disk. Location is specified in `model_path`. 
    '''
    data = (model.__class__.__name__, model.state_dict(), model.input_shape, model.num_actions)
    torch.save(data, 'history_{}'.format(date_save))

def get_env(i,j):
    '''
    Get the sample test cases for training and testing.
    '''
    return construct_task2_env()

def mainTest(agent,runs=25,env=None,t1=50,t2=40,cropping=None):
    
    import sys
    import time
    from .env import construct_task2_env,construct_task2_env_ij
    from . import state_change

    FAST_DOWNWARD_PATH = "/fast_downward/"
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("device is:",device)


    def test(agent, env=None, runs=1000, t_max=100):
        rewards = []
        for run in range(runs):
            state = env.reset()
            agent_init = {'fast_downward_path': FAST_DOWNWARD_PATH, 'agent_speed_range': (-3,-1), 'gamma' : 1}
            #agent.initialize(**agent_init)
            episode_rewards = 0.0
            for t in range(t_max):
                
                action = agent.act(state,cropping=cropping)   
                
                next_state, reward, done, info = env.step(action)
                pos_x,pos_y = state_change.pos_from_state(state)
                full_state = {
                    'state': state, 'action': action, 'reward': reward, 'next_state': next_state, 
                    'done': done, 'info': info
                }
                #agent.update(**full_state)
                state = next_state
                '''if pos_y == 0 and not(done):
                  reward = 10
                  done = True'''
                
                episode_rewards += reward
                

                if done:
                    break
            rewards.append(episode_rewards)
        avg_rewards = sum(rewards)/len(rewards)
        print("{} run(s) avg rewards : {:.1f}".format(runs, avg_rewards))
        return avg_rewards

    def timed_test(agent,task):
        start_time = time.time()
        rewards = []
        for tc in task['testcases']:
            print("[{}]".format(tc['id']), end=' ')
            avg_rewards = test(agent, tc['env'], tc['runs'], tc['t_max'])
            rewards.append(avg_rewards)
        point = sum(rewards)/len(rewards)
        elapsed_time = time.time() - start_time

        print('Point:', point)
        return(point)

        for t, remarks in [(0.4, 'fast'), (0.6, 'safe'), (0.8, 'dangerous'), (1.0, 'time limit exceeded')]:
            if elapsed_time < task['time_limit'] * t:
                print("Local runtime: {} seconds --- {}".format(elapsed_time, remarks))
                print("WARNING: do note that this might not reflect the runtime on the server.")
                break

    def get_task(env=env,runs=300,t1=50,t2=40,t_max= 50):
        
        tcs = [('task_2_tmax{}'.format(t1), t1), ('task_2_tmax{}'.format(t2), t2)]
        return {
            'time_limit': 600,
            'testcases': [{ 'id': tc, 'env':env, 'runs': runs, 't_max': t_max } for tc, t_max in tcs]
        }
   
    print("t1,t2,runs,tmax: {},{},{},{}".format(t1,t2,runs,t1))
    task = get_task(env=env,runs=runs,t1=t1,t2=t2,t_max= t1)
    # return scores
    return(timed_test(agent,task))


if __name__ == '__main__':
    
    import argparse

    parser = argparse.ArgumentParser(description='Train and test DQN agent.')
    parser.add_argument('--train', dest='train', action='store_true', help='train the agent')
    parser.add_argument('--test', dest='test', action='store_true', help='train the agent')
    parser.add_argument('--pretrain', dest='pretrain', action='store_true', help='train the agent')
    parser.add_argument('--path', dest='path', help='train the agent')
    parser.add_argument('--savepath', dest='savepath', help='train the agent')
    args = parser.parse_args()

    env = get_env(49,4)

    if args.train:
      print("train mode")
      model = train(ConvDQN, env)
      save_model(model)

    elif args.pretrain:
      print("pretrain mode")
      path_model = args.path
      savepath = args.savepath
      
      model = get_model(path_model)
      model_p = train(ConvDQN,env, pretrain=True,model_p= model,savepath=savepath)

    elif args.test:
      print("Test mode")
      FAST_DOWNWARD_PATH = "/fast_downward/"
      path_model = args.path
      print("model loaded from {}:".format(path_model))
      model = get_model(path_model)
      mainTest(model, runs=300)

