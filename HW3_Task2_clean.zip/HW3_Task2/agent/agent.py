
import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
import importlib 
import torch.optim as optim
from . import loss_src 
from . import env 
from . import state_change
import numpy as np
import importlib
importlib.reload(state_change)

class Base(nn.Module):
    def __init__(self, input_shape, num_actions,device='cpu',cropping=None,cropping_config=None):
        super().__init__()
        self.input_shape = input_shape
        self.num_actions = num_actions
        self.device = device
        #[Hauteur,largeur]
        self.cropping = cropping
        self.cropping_config = cropping
        self.construct()

    def construct(self):
        raise NotImplementedError

    def forward(self, x):
        if hasattr(self, 'features'):
            x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.layers(x)
        return x
    
    def feature_size(self):
        x = autograd.Variable(torch.zeros(1, *self.input_shape))
        if hasattr(self, 'features'):
            x = self.features(x)
        return x.view(1, -1).size(1)

class HeadController():
    #Heads config = [window cropped largeur/hauteur]
    def __init__(self, heads=None, heads_config=[8,1,1,1,4,4,4,7,7,7],lock_env=[49,9],cropping_config=None):
      # [pos_x, pos_y]
      self.lock_env = lock_env
      self.heads = heads
      self.head_current = heads_config[-1]
      self.heads_config = heads_config
      self.cropping_config = cropping_config

    def initialize():
      self.lock_env = [49,9]
      self.head_current = 7

    def update(self,state,action,reward,next_state,done,info):
      #choose end from current state 
      head,lock_env = self.choose_head_from_state(next_state)

      # If agent detect that he should changes head decision -> update head
      if self.head_current != head:
        self.head_current = head
        #starting env for new head is updating
        self.lock_env = lock_env

    def choose_head_from_state(self,next_state):
      pos_x,pos_y = state_change.pos_from_state(next_state)
      #Return head choosen from state 
      return(self.heads_config[pos_y],[pos_x,pos_y])


    def act(self,state,epsilon=0.0):
      #choose end from current state 
      rand_val = np.random.random()
      if rand_val < epsilon:
          #Return random action with outpout < num_actions        
          output = np.random.randint(0, self.num_actions)

      else:
          #Head is acting -> predictind forward of head DQN 
          output = self.heads[self.head_current].act(state,cropping=self.cropping_config)
    
      return int(output)      

     



class BaseAgent(Base):
    def act(self, state, epsilon=0.0,cropping=None):
        
        #Reduce vision of the agent (-> Provide features for DQN)
        if cropping:
          #print(cropping)
          #print(self.cropping_config)
          #Cropping state : provide features to agent 
          state_init = state_change.state_from_pos(state,cropping=self.cropping_config)
          #print("state_inint",state_init.shape)
          #print("state_inint",state_init)
        
        if not isinstance(state, torch.FloatTensor):
            state = torch.from_numpy(state_init).float().unsqueeze(0).to(self.device)
        #print(state_init)
        #Random value  
        rand_val = np.random.random()
        if rand_val < epsilon:
            #Return random action with outpout < num_actions        
            
            output = np.random.randint(0, self.num_actions)
        else:
            #Use forward prediction to choose action 
          
            output = torch.argmax(self.forward(state), dim=1)
            try:
              output = state_change.rescale_action(state_init,output)
            except:pass
        return int(output)
    

class DQN(BaseAgent):
    def construct(self):
        self.layers = nn.Sequential(
            nn.Linear(self.feature_size(), 256),
            nn.ReLU(),
            nn.Linear(256, self.num_actions)
        )

class ConvDQN(DQN):
    def construct(self):
        self.features = nn.Sequential(
            nn.Conv2d(self.input_shape[0], 32, kernel_size=2),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=2),
            nn.ReLU(),
        )
        super().construct()

class AtariDQN(DQN):
    def construct(self):
        self.features = nn.Sequential(
            nn.Conv2d(self.input_shape[0], 32, kernel_size=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3),
            nn.ReLU()
        )
        self.layers = nn.Sequential(
            nn.Linear(self.feature_size(), 512),
            nn.ReLU(),
            nn.Linear(512, self.num_actions)
        )



