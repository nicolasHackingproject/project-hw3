
def compute_loss(model, target, states, actions, rewards, next_states, dones):
    
    # resize tensors
    actions = actions.view(actions.size(0), 1).to(device)
    dones = dones.view(dones.size(0), 1).int().to(device)

    next_states = next_states.float().to(device)
    states = states.float().to(device)
    rewards = rewards.to(device)

    # compute loss
    next_Q = target.forward(next_states)
    curr_Q = model.forward(states).gather(1, actions)
    
    max_next_Q = (torch.max(next_Q, 1)[0])
    max_next_Q = (max_next_Q.view(max_next_Q.size(0), 1))
    
    expected_Q = (rewards + (1 - dones.int()) * gamma * max_next_Q)

    loss = F.mse_loss(curr_Q, expected_Q) 

    return loss

def optimize(model, target, memory, optimizer):
    '''
    Optimize the model for a sampled batch with a length of `batch_size`
    '''
    batch = memory.sample(batch_size)
    loss = compute_loss(model, target, *batch)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    return loss

def compute_epsilon(episode,min_epsilon,max_epsilon,epsilon_decay):
    '''
    Compute epsilon used for epsilon-greedy exploration
    '''
    epsilon = min_epsilon + (max_epsilon - min_epsilon) * math.exp(-1. * episode / epsilon_decay)
    return epsilon

  
