
import numpy as np

def pos_from_state(state):
  try:
    
    for i in range(0,len(state[0,:,0])):
      column = (np.where(state[1,i,:] == 1.))
      if len(column[0]) > 0:
        column = column[0][0]
        row = i 
        return(column,row)
  except:
    print(state,len(state[0,:,0]))


def rescale_action(state_cropped,action):
  #print("state cropped shape",state_cropped.shape)
  #print("cropped",state_cropped)
  #print(state_cropped.shape)
  try:
    pos_x,pos_y = pos_from_state(state_cropped)
    if pos_y == 0 and action == 0:
      return 4 
    if pos_y == 2 and action == 1:
      return 4 
  except:pass
    #print("state cropped",state_cropped)
    #print("state cropped",state_cropped.shape)
  #print("pos_x,pos_y",pos_x,pos_y)
  # If pos_y == 0 and action = 0 -> action = 4 (head was trained with barrier on the top/bottom but in real world)
  
  return action

def state_from_pos(state,cropping=None):

  x_debut = cropping.x_debut
  y_debut = cropping.y_debut
  devant = cropping.devant
  derriere = cropping.derriere
  hauteur = cropping.hauteur
  largeur = cropping.largeur
  #Crop state 
  #y_max = pos_y + (hauteur+1)//2-1
  #y_min = pos_y - (hauteur)//2
  #print(pos_x,pos_y)
  y_max = y_debut + 1
  y_min = y_debut - hauteur +1  

  #x_max = pos_x + largeur //3 
  #x_min = pos_x - 2*(largeur//3)
  x_max = x_debut + derriere
  x_min = x_debut - devant

  #print(x_min,x_max)
  #print("xmin,xmax,ymin,ymax,largeur,hauteur,pos_x,pos_y",x_min,x_max,y_min,y_max,largeur,hauteur,x_debut,y_debut,devant,derriere)

  if y_max > 9:
    y_max = 10
    y_min = 9-hauteur+1

  elif y_min < 0:
    
    y_max = hauteur-1
    y_min = 0 
    
  #print("input state:",state.shape)
  if x_min < 0:
    x_min = 0 
    x_max = devant+derriere+1
  elif x_max > 49:
    res = np.zeros([4,hauteur,devant+derriere+1])
    delta1 = devant
    #print("delta1",delta1)
    res[:,:,0:delta1+1] = state[:,y_min:(y_max),(x_debut-devant):x_debut+1]
    
    delta2 = 50-x_debut+delta1
    #print("delta1,delta2",delta1,delta2)
    res[:,:,delta1+1:delta2] = state[:,y_min:(y_max),(x_debut+1):50]

    delta3 = devant+derriere+1
    #print("delta1,delta2,delta3",delta1,delta2,delta3)
    res[:,:,delta2+1:delta3] = state[:,y_min:(y_max),0:delta3-delta2-1]
    
    return(res)
  
  #print("output state:",state[:,y_min:(y_max),x_min:(x_max+1)].shape)
  return(state[:,y_min:(y_max),x_min:(x_max+1)])

 # Crop initial state
#pos_y,pos_x = pos_from_state(state)
#state = state_from_pos(pos_x,pos_y,state)''
